#Exercises for the ggplot2 course

#Exercise 1#
#(i)
library(ggplot2)
#(ii)
head(diamonds)
str(diamonds)


#Exercise 2#
x<-c(0,3,6)
y<-c(0,5,0)
dat<-data.frame(x,y)
#(i)
ggplot(data = dat,aes(x,y))+geom_polygon()
#(ii)
ggplot(data = dat,aes(x,y))+geom_polygon(fill="green")


#Exercise 3#
#(i)
ggplot(data=diamonds,aes(x=carat,y=price))+geom_point()
#(ii)
ggplot(diamonds, aes(carat, price, colour = cut))+geom_point()


#Exercise 4#
#(i)
df <- data.frame(x = c(3, 1, 5), y = c(2, 4, 6), label = c("a","b","c"))
p <- ggplot(df, aes(x, y, label = label)) + xlab(NULL) + ylab(NULL)
#(ii)
p + geom_point(colour=c(1,2,3)) + ggtitle("Points")
# for centering title: + theme(plot.title = element_text(hjust = 0.5))
# or make this as default: theme_update(plot.title = element_text(hjust = 0.5))

#(iii)
p + geom_bar(stat="identity")
#(iv)
p + geom_line() + ggtitle("geom_line")
#(v)
p + geom_area() + ggtitle("geom_area")

  

#Exercise 5#
#(i)
d <- ggplot(diamonds, aes(carat))
d + stat_bin(geom = "bar", fill="blue", color=1)
#(iii)
d <- ggplot(diamonds, aes(NULL,carat)) 
d + geom_boxplot(fill = "white", colour = "#3366FF") +theme(axis.title.x=element_blank(),
        axis.text.x=element_blank(),
        axis.ticks.x=element_blank())


#Exercise 6#
#(i)
ggplot(diamonds,aes(carat,price))+geom_point()
#(ii)
ggplot(diamonds,aes(carat,price,col=clarity))+geom_point()
#(iii)
ggplot(diamonds,aes(carat,price,col=clarity))+geom_point()+geom_smooth(method = lm)
#or:
ggplot(diamonds,aes(carat,price,col=clarity))+geom_point()+geom_smooth(method = lm,se=F)


#Exercise 7#
#(i)
  ggplot(diamonds,aes(color)) +
  geom_bar(aes(fill=cut)) 
  # coord_polar() +
 # ggtitle('Mean dimond price') +
 # theme_void() +
 # theme(plot.title = element_text(hjust = 0.5, size = 16, face = 'bold'))

 